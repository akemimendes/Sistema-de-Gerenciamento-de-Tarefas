package com.treina.recife.sgp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaDeGerenciamentoDeTarefasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaDeGerenciamentoDeTarefasApplication.class, args);
	}

}
